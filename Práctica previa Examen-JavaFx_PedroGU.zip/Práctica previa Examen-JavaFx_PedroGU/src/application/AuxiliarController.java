package application;

public class AuxiliarController {

}
