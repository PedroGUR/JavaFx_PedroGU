package application;

import java.io.IOException;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class PrincipalController {
	public Label texto;
	public TextField aTexto;
	
	public TextField user;
	public TextField pass;
	
	public void escribir() {
		texto.setText(aTexto.getText());
		aTexto.setText("");
	}
	
	public void nuevo() {
		if(pass.getText().equals("1234")) {
			FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Auxiliar.fxml"));
		    Parent root1;
			try {
				root1 = (Parent) fxmlLoader.load();
				Stage stage = new Stage();
			    stage.initModality(Modality.APPLICATION_MODAL);
			    //
			    //scene.getStylesheets().add(Nueva.class.getResource("application.css").toExternalForm();
			    //
			    stage.setTitle("VENTANA NUEVA");
			    stage.setScene(new Scene(root1,400,400));  
			    stage.show();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
	
}
